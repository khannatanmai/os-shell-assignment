#ifndef _RUN_PROCESS_H_
#define _RUN_PROCESS_H_

int run_process(char **tokens, int number_of_tokens, char home_dir[]);

#endif
