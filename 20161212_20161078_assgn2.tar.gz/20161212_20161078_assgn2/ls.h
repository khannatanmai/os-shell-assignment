#ifndef _LS_H
#define _LS_H

int execute_ls(char **tokens, int number_of_tokens);

#endif
