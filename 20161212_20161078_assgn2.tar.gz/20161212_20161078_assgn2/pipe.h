#ifndef _PIPE_H
#define _PIPE_H

int pipe(char **tokens, int num);

#endif