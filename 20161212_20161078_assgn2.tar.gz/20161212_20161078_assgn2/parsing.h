#ifndef _PARSING_H_
#define _PARSING_H_

int parse(char str[],char *args[]);

#endif